<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Dashboard</div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <div class="row text-center">
                            <div class="col">
                                <div class="card">
                                    <div class="card-header">
                                        <h5>user (<small><?php echo e($users); ?></small>)</h5>
                                    </div>
                                    <div class="card-body">
                                        <a href="<?php echo e(route('admin.user.index')); ?>" class="btn btn-primary
                                        btn-sm">view</a>

                                    </div>
                                </div>
                            </div>
                            <div class="col">
                                <div class="card">
                                    <div class="card-header">
                                        <h5>menu (<small><?php echo e($menus); ?></small>)</h5>
                                    </div>
                                    <div class="card-body">
                                        <a href="<?php echo e(route('admin.menu.index')); ?>" class="btn btn-primary
                                        btn-sm">view</a>

                                        <a href="<?php echo e(route('admin.menu.create')); ?>" class="btn btn-success
                                        btn-sm">create</a>

                                    </div>
                                </div>
                            </div>
                            <div class="col">
                                <div class="card">
                                    <div class="card-header">
                                        <h5>order (<small><?php echo e($orders); ?></small>)</h5>
                                    </div>
                                    <div class="card-body">
                                        <a href="<?php echo e(route('admin.order.index')); ?>" class="btn btn-primary
                                        btn-sm">view</a>

                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/learning/Desktop/code/mobile_app/resources/views/home.blade.php ENDPATH**/ ?>