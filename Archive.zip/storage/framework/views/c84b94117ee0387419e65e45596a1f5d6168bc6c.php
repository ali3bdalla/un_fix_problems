<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        menus <a href="<?php echo e(route('admin.menu.create')); ?>" class="btn btn-success btn-sm">
                            create
                        </a>
                    </div>

                    <div class="card-body">
                        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card-header">
                                <div>
                                    <span class="badge badge-primary"><?php echo e($menu->id); ?></span>

                                </div>
                                <div class="row">
                                    <div class="col"><?php echo e($menu->title); ?></div>
                                    <div class="col text-center">
                                        <form class="form-inline" action="<?php echo e(route('admin.menu.destroy',$menu->id)); ?>"
                                        method="post">
                                            <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm">
                                                delete
                                            </button>
                                        </form>

                                    </div>
                                    <div class="col text-right"><?php echo e($menu->created_at); ?></div>
                                </div>




                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="card-footer text-center">
                        <?php echo e($menus->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/learning/Desktop/code/mobile_app/resources/views/menu/index.blade.php ENDPATH**/ ?>