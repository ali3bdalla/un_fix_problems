INSERT INTO `menus`(`id`, `title`, `parent_id`, `created_at`, `updated_at`)
VALUES
(NULL ,'انقطاع كهرباء','0',null,null),
(NULL ,'انقطاع ماسورة ماء','0',null,null)